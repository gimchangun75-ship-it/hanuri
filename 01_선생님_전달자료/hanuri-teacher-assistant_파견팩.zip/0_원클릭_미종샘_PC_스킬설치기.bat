@echo off
cd /d "%~dp0"
where python >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo.
    echo ============================================================
    echo   [ERROR] Python is not installed or not in PATH.
    echo   Please install Python 3.8+ from https://www.python.org
    echo ============================================================
    echo.
    pause
    exit /b 1
)
python -X utf8 install_hanuri_skill.py
pause > nul
